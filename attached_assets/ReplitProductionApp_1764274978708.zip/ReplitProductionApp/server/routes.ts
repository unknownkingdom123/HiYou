import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import multer from "multer";
import path from "path";
import fs from "fs";
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import Fuse from "fuse.js";
import { loginSchema, signupSchema, chatMessageSchema, insertExternalLinkSchema } from "@shared/schema";
import type { Pdf, ExternalLink, ChatResponse } from "@shared/schema";

function sanitizePdf(pdf: Pdf): Omit<Pdf, "filePath" | "filename"> & { downloadUrl: string } {
  const { filePath, filename, ...rest } = pdf;
  return {
    ...rest,
    downloadUrl: `/api/pdfs/${pdf.id}/download`,
  };
}

function sanitizePdfs(pdfs: Pdf[]): (Omit<Pdf, "filePath" | "filename"> & { downloadUrl: string })[] {
  return pdfs.map(sanitizePdf);
}

const JWT_SECRET = process.env.SESSION_SECRET || "pdf-library-secret-key";
const UPLOADS_DIR = path.join(process.cwd(), "uploads");

if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

const upload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, UPLOADS_DIR);
    },
    filename: (req, file, cb) => {
      const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
      cb(null, uniqueSuffix + path.extname(file.originalname));
    },
  }),
  fileFilter: (req, file, cb) => {
    if (file.mimetype === "application/pdf") {
      cb(null, true);
    } else {
      cb(new Error("Only PDF files are allowed"));
    }
  },
  limits: {
    fileSize: 50 * 1024 * 1024,
  },
});

interface AuthRequest extends Request {
  userId?: string;
  isAdmin?: boolean;
}

function authenticateToken(req: AuthRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers["authorization"];
  const token = authHeader && authHeader.split(" ")[1];

  if (!token) {
    return res.status(401).json({ message: "Authentication required" });
  }

  jwt.verify(token, JWT_SECRET, (err, decoded) => {
    if (err) {
      return res.status(403).json({ message: "Invalid or expired token" });
    }
    const payload = decoded as { userId: string; isAdmin: boolean };
    req.userId = payload.userId;
    req.isAdmin = payload.isAdmin;
    next();
  });
}

function requireAdmin(req: AuthRequest, res: Response, next: NextFunction) {
  if (!req.isAdmin) {
    return res.status(403).json({ message: "Admin access required" });
  }
  next();
}

function generateToken(userId: string, isAdmin: boolean): string {
  return jwt.sign({ userId, isAdmin }, JWT_SECRET, { expiresIn: "7d" });
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  app.post("/api/auth/signup", async (req, res) => {
    try {
      const result = signupSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ message: result.error.errors[0].message });
      }

      const { email, username, password, name } = result.data;

      const existingEmail = await storage.getUserByEmail(email);
      if (existingEmail) {
        return res.status(400).json({ message: "Email already registered" });
      }

      const existingUsername = await storage.getUserByUsername(username);
      if (existingUsername) {
        return res.status(400).json({ message: "Username already taken" });
      }

      const user = await storage.createUser({ email, username, password, name });
      const token = generateToken(user.id, user.isAdmin);

      const { password: _, ...userWithoutPassword } = user;
      res.json({ user: userWithoutPassword, token });
    } catch (error) {
      console.error("Signup error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const result = loginSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ message: result.error.errors[0].message });
      }

      const { email, password } = result.data;
      const user = await storage.getUserByEmail(email);

      if (!user) {
        return res.status(401).json({ message: "Invalid email or password" });
      }

      const validPassword = await bcrypt.compare(password, user.password);
      if (!validPassword) {
        return res.status(401).json({ message: "Invalid email or password" });
      }

      const token = generateToken(user.id, user.isAdmin);
      const { password: _, ...userWithoutPassword } = user;
      res.json({ user: userWithoutPassword, token });
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/auth/admin/login", async (req, res) => {
    try {
      const result = loginSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ message: result.error.errors[0].message });
      }

      const { email, password } = result.data;
      const user = await storage.getUserByEmail(email);

      if (!user || !user.isAdmin) {
        return res.status(401).json({ message: "Invalid admin credentials" });
      }

      const validPassword = await bcrypt.compare(password, user.password);
      if (!validPassword) {
        return res.status(401).json({ message: "Invalid admin credentials" });
      }

      const token = generateToken(user.id, user.isAdmin);
      const { password: _, ...userWithoutPassword } = user;
      res.json({ user: userWithoutPassword, token });
    } catch (error) {
      console.error("Admin login error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/user/stats", authenticateToken, async (req: AuthRequest, res) => {
    try {
      const stats = await storage.getUserStats(req.userId!);
      res.json(stats);
    } catch (error) {
      console.error("Get user stats error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/user/downloads", authenticateToken, async (req: AuthRequest, res) => {
    try {
      const downloads = await storage.getUserDownloadHistory(req.userId!);
      res.json(downloads);
    } catch (error) {
      console.error("Get user downloads error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/chat", authenticateToken, async (req: AuthRequest, res) => {
    try {
      const result = chatMessageSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ message: result.error.errors[0].message });
      }

      const { message } = result.data;
      const allPdfs = await storage.getAllPdfs();
      const allLinks = await storage.getAllExternalLinks();

      const pdfFuse = new Fuse(allPdfs, {
        keys: [
          { name: "title", weight: 0.4 },
          { name: "author", weight: 0.2 },
          { name: "category", weight: 0.15 },
          { name: "description", weight: 0.15 },
          { name: "tags", weight: 0.1 },
        ],
        threshold: 0.4,
        includeScore: true,
      });

      const linkFuse = new Fuse(allLinks, {
        keys: [
          { name: "title", weight: 0.5 },
          { name: "description", weight: 0.3 },
          { name: "category", weight: 0.2 },
        ],
        threshold: 0.4,
        includeScore: true,
      });

      const pdfResults = pdfFuse.search(message);
      const linkResults = linkFuse.search(message);

      if (pdfResults.length > 0) {
        const bestMatch = sanitizePdf(pdfResults[0].item);
        const similar = sanitizePdfs(pdfResults.slice(1, 4).map((r) => r.item));

        res.json({
          bestMatch,
          similar,
          externalLink: null,
          message: `I found "${bestMatch.title}" by ${bestMatch.author}. This looks like a great match for what you're looking for!`,
        });
      } else if (linkResults.length > 0) {
        res.json({
          bestMatch: null,
          similar: [],
          externalLink: linkResults[0].item,
          message: `I couldn't find a PDF in our library, but I found an external resource that might help: "${linkResults[0].item.title}"`,
        });
      } else {
        res.json({
          bestMatch: null,
          similar: [],
          externalLink: null,
          message: "I couldn't find any matching documents in our library. Try different keywords or ask for a specific subject like 'physics notes' or 'programming book'.",
        });
      }
    } catch (error) {
      console.error("Chat error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/pdfs/:id/download", async (req, res) => {
    try {
      const pdf = await storage.getPdf(req.params.id);
      if (!pdf) {
        return res.status(404).json({ message: "PDF not found" });
      }

      const filePath = path.join(UPLOADS_DIR, pdf.filename);
      
      if (!fs.existsSync(filePath)) {
        const dummyContent = Buffer.from(`This is a placeholder PDF for: ${pdf.title}\nBy: ${pdf.author}\n\nThis PDF would contain the actual content in a production environment.`);
        return res.setHeader("Content-Type", "application/pdf")
          .setHeader("Content-Disposition", `attachment; filename="${pdf.originalName}"`)
          .send(dummyContent);
      }

      res.download(filePath, pdf.originalName);
    } catch (error) {
      console.error("Download error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/pdfs/:id/track-download", authenticateToken, async (req: AuthRequest, res) => {
    try {
      const pdf = await storage.getPdf(req.params.id);
      if (!pdf) {
        return res.status(404).json({ message: "PDF not found" });
      }

      await storage.createDownloadHistory({
        userId: req.userId!,
        pdfId: pdf.id,
      });

      res.json({ success: true });
    } catch (error) {
      console.error("Track download error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/admin/stats", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const stats = await storage.getAdminStats();
      res.json(stats);
    } catch (error) {
      console.error("Get admin stats error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/admin/pdfs", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const pdfs = await storage.getAllPdfs();
      res.json(pdfs);
    } catch (error) {
      console.error("Get all PDFs error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/admin/pdfs/recent", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const pdfs = await storage.getRecentPdfs(10);
      res.json(pdfs);
    } catch (error) {
      console.error("Get recent PDFs error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/admin/pdfs", authenticateToken, requireAdmin, upload.single("file"), async (req: AuthRequest, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const { title, author, category, description, tags } = req.body;

      if (!title || !author || !category) {
        fs.unlinkSync(req.file.path);
        return res.status(400).json({ message: "Title, author, and category are required" });
      }

      const tagArray = tags ? tags.split(",").map((t: string) => t.trim()).filter(Boolean) : [];

      const pdf = await storage.createPdf({
        title,
        author,
        category,
        description: description || null,
        tags: tagArray.length > 0 ? tagArray : null,
        filename: req.file.filename,
        originalName: req.file.originalname,
        fileSize: req.file.size,
        filePath: `/uploads/${req.file.filename}`,
        uploadedBy: req.userId,
      });

      res.json(pdf);
    } catch (error) {
      console.error("Upload PDF error:", error);
      if (req.file) {
        fs.unlinkSync(req.file.path);
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.patch("/api/admin/pdfs/:id", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const { title, author, category, description, tags } = req.body;
      
      const tagArray = typeof tags === "string" 
        ? tags.split(",").map((t: string) => t.trim()).filter(Boolean) 
        : tags;

      const pdf = await storage.updatePdf(req.params.id, {
        title,
        author,
        category,
        description: description || null,
        tags: tagArray && tagArray.length > 0 ? tagArray : null,
      });

      if (!pdf) {
        return res.status(404).json({ message: "PDF not found" });
      }

      res.json(pdf);
    } catch (error) {
      console.error("Update PDF error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.delete("/api/admin/pdfs/:id", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const pdf = await storage.getPdf(req.params.id);
      if (!pdf) {
        return res.status(404).json({ message: "PDF not found" });
      }

      const filePath = path.join(UPLOADS_DIR, pdf.filename);
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
      }

      await storage.deletePdf(req.params.id);
      res.json({ success: true });
    } catch (error) {
      console.error("Delete PDF error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/admin/links", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const links = await storage.getAllExternalLinks();
      res.json(links);
    } catch (error) {
      console.error("Get all links error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/admin/links", authenticateToken, requireAdmin, async (req: AuthRequest, res) => {
    try {
      const result = insertExternalLinkSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ message: result.error.errors[0].message });
      }

      const link = await storage.createExternalLink({
        ...result.data,
        addedBy: req.userId,
      });

      res.json(link);
    } catch (error) {
      console.error("Create link error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.delete("/api/admin/links/:id", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const success = await storage.deleteExternalLink(req.params.id);
      if (!success) {
        return res.status(404).json({ message: "Link not found" });
      }
      res.json({ success: true });
    } catch (error) {
      console.error("Delete link error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/admin/users", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      const usersWithoutPasswords = users.map(({ password, ...user }) => user);
      res.json(usersWithoutPasswords);
    } catch (error) {
      console.error("Get all users error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/admin/users/:id/downloads", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const downloads = await storage.getUserDownloads(req.params.id);
      res.json(downloads);
    } catch (error) {
      console.error("Get user downloads error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  return httpServer;
}
