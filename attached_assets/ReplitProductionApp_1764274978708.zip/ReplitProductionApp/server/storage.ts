import { 
  type User, 
  type InsertUser, 
  type Pdf, 
  type InsertPdf,
  type ExternalLink,
  type InsertExternalLink,
  type DownloadHistory,
  type InsertDownloadHistory,
  type UserWithStats,
  type DownloadHistoryWithPdf
} from "@shared/schema";
import { randomUUID } from "crypto";
import bcrypt from "bcryptjs";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser & { isAdmin?: boolean }): Promise<User>;
  getAllUsers(): Promise<UserWithStats[]>;
  getUserDownloads(userId: string): Promise<DownloadHistoryWithPdf[]>;

  getPdf(id: string): Promise<Pdf | undefined>;
  getAllPdfs(): Promise<Pdf[]>;
  getRecentPdfs(limit?: number): Promise<Pdf[]>;
  createPdf(pdf: InsertPdf & { filename: string; originalName: string; fileSize: number; filePath: string; uploadedBy?: string }): Promise<Pdf>;
  updatePdf(id: string, data: Partial<InsertPdf>): Promise<Pdf | undefined>;
  deletePdf(id: string): Promise<boolean>;
  searchPdfs(query: string): Promise<Pdf[]>;

  getExternalLink(id: string): Promise<ExternalLink | undefined>;
  getAllExternalLinks(): Promise<ExternalLink[]>;
  createExternalLink(link: InsertExternalLink & { addedBy?: string }): Promise<ExternalLink>;
  deleteExternalLink(id: string): Promise<boolean>;
  searchExternalLinks(query: string): Promise<ExternalLink[]>;

  createDownloadHistory(data: InsertDownloadHistory): Promise<DownloadHistory>;
  getUserDownloadHistory(userId: string): Promise<DownloadHistoryWithPdf[]>;
  getUserStats(userId: string): Promise<{ totalDownloads: number; memberSince: Date }>;
  getAdminStats(): Promise<{ totalPdfs: number; totalUsers: number; totalDownloads: number; storageUsed: number }>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private pdfs: Map<string, Pdf>;
  private externalLinks: Map<string, ExternalLink>;
  private downloadHistory: Map<string, DownloadHistory>;

  constructor() {
    this.users = new Map();
    this.pdfs = new Map();
    this.externalLinks = new Map();
    this.downloadHistory = new Map();
    
    this.seedData();
  }

  private async seedData() {
    const adminPassword = await bcrypt.hash("admin123", 10);
    const adminId = randomUUID();
    const admin: User = {
      id: adminId,
      username: "admin",
      email: "admin@library.com",
      password: adminPassword,
      name: "Admin User",
      isAdmin: true,
      createdAt: new Date(),
    };
    this.users.set(adminId, admin);

    const samplePdfs = [
      {
        title: "Engineering Physics Vol. 1",
        author: "Dr. M.N. Avadhanulu",
        category: "Physics",
        description: "Comprehensive textbook covering mechanics, thermodynamics, and waves for engineering students",
        tags: ["physics", "engineering", "mechanics", "waves", "thermodynamics"],
      },
      {
        title: "C Programming Language",
        author: "Brian W. Kernighan, Dennis M. Ritchie",
        category: "Computer Science",
        description: "The definitive guide to C programming, written by the creators of the language",
        tags: ["programming", "c", "computer science", "coding"],
      },
      {
        title: "Engineering Mathematics",
        author: "B.S. Grewal",
        category: "Mathematics",
        description: "Higher engineering mathematics covering calculus, differential equations, and linear algebra",
        tags: ["mathematics", "calculus", "engineering", "algebra"],
      },
      {
        title: "Data Structures and Algorithms",
        author: "Thomas H. Cormen",
        category: "Computer Science",
        description: "Introduction to algorithms with comprehensive coverage of data structures",
        tags: ["algorithms", "data structures", "programming", "computer science"],
      },
      {
        title: "Organic Chemistry",
        author: "Morrison and Boyd",
        category: "Chemistry",
        description: "Classic textbook on organic chemistry reactions and mechanisms",
        tags: ["chemistry", "organic", "reactions", "mechanisms"],
      },
    ];

    for (const pdfData of samplePdfs) {
      const id = randomUUID();
      const pdf: Pdf = {
        id,
        ...pdfData,
        filename: `${pdfData.title.toLowerCase().replace(/\s+/g, '-')}.pdf`,
        originalName: `${pdfData.title}.pdf`,
        fileSize: Math.floor(Math.random() * 10000000) + 1000000,
        filePath: `/uploads/${id}.pdf`,
        uploadedBy: adminId,
        createdAt: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000),
      };
      this.pdfs.set(id, pdf);
    }

    const sampleLinks = [
      {
        title: "MIT OpenCourseWare - Physics",
        url: "https://ocw.mit.edu/courses/physics/",
        description: "Free physics courses and materials from MIT",
        category: "Physics",
      },
      {
        title: "Khan Academy - Mathematics",
        url: "https://www.khanacademy.org/math",
        description: "Free math courses and practice exercises",
        category: "Mathematics",
      },
    ];

    for (const linkData of sampleLinks) {
      const id = randomUUID();
      const link: ExternalLink = {
        id,
        ...linkData,
        addedBy: adminId,
        createdAt: new Date(),
      };
      this.externalLinks.set(id, link);
    }
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email.toLowerCase() === email.toLowerCase()
    );
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username.toLowerCase() === username.toLowerCase()
    );
  }

  async createUser(insertUser: InsertUser & { isAdmin?: boolean }): Promise<User> {
    const id = randomUUID();
    const hashedPassword = await bcrypt.hash(insertUser.password, 10);
    const user: User = { 
      ...insertUser, 
      id, 
      password: hashedPassword,
      isAdmin: insertUser.isAdmin ?? false,
      createdAt: new Date() 
    };
    this.users.set(id, user);
    return user;
  }

  async getAllUsers(): Promise<UserWithStats[]> {
    const users = Array.from(this.users.values()).filter(u => !u.isAdmin);
    const usersWithStats: UserWithStats[] = [];
    
    for (const user of users) {
      const downloads = Array.from(this.downloadHistory.values()).filter(
        d => d.userId === user.id
      );
      usersWithStats.push({
        ...user,
        totalDownloads: downloads.length,
      });
    }
    
    return usersWithStats.sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async getUserDownloads(userId: string): Promise<DownloadHistoryWithPdf[]> {
    return this.getUserDownloadHistory(userId);
  }

  async getPdf(id: string): Promise<Pdf | undefined> {
    return this.pdfs.get(id);
  }

  async getAllPdfs(): Promise<Pdf[]> {
    return Array.from(this.pdfs.values()).sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async getRecentPdfs(limit = 10): Promise<Pdf[]> {
    return (await this.getAllPdfs()).slice(0, limit);
  }

  async createPdf(pdfData: InsertPdf & { filename: string; originalName: string; fileSize: number; filePath: string; uploadedBy?: string }): Promise<Pdf> {
    const id = randomUUID();
    const pdf: Pdf = {
      id,
      title: pdfData.title,
      author: pdfData.author,
      category: pdfData.category,
      description: pdfData.description ?? null,
      tags: pdfData.tags ?? null,
      filename: pdfData.filename,
      originalName: pdfData.originalName,
      fileSize: pdfData.fileSize,
      filePath: pdfData.filePath,
      uploadedBy: pdfData.uploadedBy ?? null,
      createdAt: new Date(),
    };
    this.pdfs.set(id, pdf);
    return pdf;
  }

  async updatePdf(id: string, data: Partial<InsertPdf>): Promise<Pdf | undefined> {
    const pdf = this.pdfs.get(id);
    if (!pdf) return undefined;
    
    const updatedPdf: Pdf = {
      ...pdf,
      ...data,
      tags: data.tags !== undefined ? data.tags : pdf.tags,
    };
    this.pdfs.set(id, updatedPdf);
    return updatedPdf;
  }

  async deletePdf(id: string): Promise<boolean> {
    return this.pdfs.delete(id);
  }

  async searchPdfs(query: string): Promise<Pdf[]> {
    const allPdfs = Array.from(this.pdfs.values());
    const lowerQuery = query.toLowerCase();
    
    return allPdfs.filter(pdf => 
      pdf.title.toLowerCase().includes(lowerQuery) ||
      pdf.author.toLowerCase().includes(lowerQuery) ||
      pdf.category.toLowerCase().includes(lowerQuery) ||
      pdf.description?.toLowerCase().includes(lowerQuery) ||
      pdf.tags?.some(tag => tag.toLowerCase().includes(lowerQuery))
    );
  }

  async getExternalLink(id: string): Promise<ExternalLink | undefined> {
    return this.externalLinks.get(id);
  }

  async getAllExternalLinks(): Promise<ExternalLink[]> {
    return Array.from(this.externalLinks.values()).sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async createExternalLink(linkData: InsertExternalLink & { addedBy?: string }): Promise<ExternalLink> {
    const id = randomUUID();
    const link: ExternalLink = {
      id,
      title: linkData.title,
      url: linkData.url,
      description: linkData.description ?? null,
      category: linkData.category ?? null,
      addedBy: linkData.addedBy ?? null,
      createdAt: new Date(),
    };
    this.externalLinks.set(id, link);
    return link;
  }

  async deleteExternalLink(id: string): Promise<boolean> {
    return this.externalLinks.delete(id);
  }

  async searchExternalLinks(query: string): Promise<ExternalLink[]> {
    const allLinks = Array.from(this.externalLinks.values());
    const lowerQuery = query.toLowerCase();
    
    return allLinks.filter(link => 
      link.title.toLowerCase().includes(lowerQuery) ||
      link.description?.toLowerCase().includes(lowerQuery) ||
      link.category?.toLowerCase().includes(lowerQuery)
    );
  }

  async createDownloadHistory(data: InsertDownloadHistory): Promise<DownloadHistory> {
    const id = randomUUID();
    const history: DownloadHistory = {
      id,
      userId: data.userId,
      pdfId: data.pdfId,
      downloadedAt: new Date(),
    };
    this.downloadHistory.set(id, history);
    return history;
  }

  async getUserDownloadHistory(userId: string): Promise<DownloadHistoryWithPdf[]> {
    const history = Array.from(this.downloadHistory.values())
      .filter(h => h.userId === userId)
      .sort((a, b) => new Date(b.downloadedAt).getTime() - new Date(a.downloadedAt).getTime());
    
    const historyWithPdfs: DownloadHistoryWithPdf[] = [];
    for (const h of history) {
      const pdf = await this.getPdf(h.pdfId);
      if (pdf) {
        historyWithPdfs.push({ ...h, pdf });
      }
    }
    return historyWithPdfs;
  }

  async getUserStats(userId: string): Promise<{ totalDownloads: number; memberSince: Date }> {
    const user = await this.getUser(userId);
    const downloads = Array.from(this.downloadHistory.values()).filter(h => h.userId === userId);
    return {
      totalDownloads: downloads.length,
      memberSince: user?.createdAt || new Date(),
    };
  }

  async getAdminStats(): Promise<{ totalPdfs: number; totalUsers: number; totalDownloads: number; storageUsed: number }> {
    const users = Array.from(this.users.values()).filter(u => !u.isAdmin);
    const pdfs = Array.from(this.pdfs.values());
    const downloads = Array.from(this.downloadHistory.values());
    const storageUsed = pdfs.reduce((sum, pdf) => sum + pdf.fileSize, 0);
    
    return {
      totalPdfs: pdfs.length,
      totalUsers: users.length,
      totalDownloads: downloads.length,
      storageUsed,
    };
  }
}

export const storage = new MemStorage();
