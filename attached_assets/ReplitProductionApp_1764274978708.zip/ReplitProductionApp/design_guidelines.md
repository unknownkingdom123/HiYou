# AI PDF Library Bot - Design Guidelines

## Design Approach
**System:** Material Design-inspired approach optimized for data-rich dashboards and form-heavy interfaces. This provides clear hierarchy, excellent form patterns, and proven admin UI components.

## Typography System

**Font Family:** Inter (Google Fonts)
- Primary: Inter for all text
- Monospace: 'Courier New' for file sizes and technical data

**Type Scale:**
- Hero/Page Headers: text-4xl font-bold (36px)
- Section Headers: text-2xl font-semibold (24px)
- Card Titles: text-lg font-medium (18px)
- Body Text: text-base (16px)
- Metadata/Labels: text-sm font-medium (14px)
- Captions: text-xs (12px)

## Layout System

**Spacing Primitives:** Use Tailwind units of 2, 4, 6, and 8 consistently
- Component padding: p-6
- Section spacing: space-y-8
- Card gaps: gap-6
- Form field spacing: space-y-4
- Button padding: px-6 py-2

**Grid System:**
- Admin PDF Grid: grid-cols-1 md:grid-cols-2 lg:grid-cols-3
- User History List: Single column with cards
- Admin User Management: Table layout on desktop, cards on mobile

## Core Components

### Navigation
**Admin Sidebar:**
- Fixed left sidebar, w-64, full height
- Logo at top with p-6
- Navigation items with px-4 py-3, rounded-lg
- Icons from Heroicons (outline style)
- Current page indicated with bolder font weight
- Bottom section for admin profile/logout

**User Header:**
- Horizontal top navigation, sticky
- Logo left, user profile/logout right
- Chatbot toggle button (if not on chat page)
- Max-width container: max-w-7xl mx-auto px-6

### Cards
**PDF Card (Admin & User):**
- Rounded corners: rounded-xl
- Border: border
- Padding: p-6
- Hover state: translate-y-[-2px] transition
- Structure: Title (text-lg font-semibold) → Author/Category (text-sm) → Tags (flex gap-2) → Actions (bottom)
- File size badge: Pill shape, text-xs, px-3 py-1

### Forms
**Upload Form (Admin):**
- Single column layout, max-w-2xl
- Each field: Label (text-sm font-medium mb-2) + Input (p-3 rounded-lg border)
- File upload: Dashed border dropzone, h-32, centered text
- Text inputs: Full width with clear focus states
- Select dropdowns: Chevron icon right
- Submit button: Full width at bottom, py-3

**Auth Forms:**
- Centered card: max-w-md mx-auto, mt-20
- Card padding: p-8
- Logo/title centered at top
- Form fields: space-y-4
- Primary action button: w-full
- Link to alternate action (signup/login): text-center mt-4

### Data Display
**User History Table:**
- Card container with overflow-x-auto
- Headers: Sticky, font-semibold, text-sm
- Rows: Border-bottom, py-4 px-6
- Mobile: Stack as cards with labels

**Admin PDF Management:**
- Table with columns: Thumbnail | Title/Author | Category | Size | Actions
- Action buttons: Edit (icon), Delete (icon), grouped with gap-2
- Search bar above table: Full width, p-3, with search icon

### Chatbot Interface
**Layout:**
- Fixed height container: h-[calc(100vh-12rem)]
- Messages area: Flex-1, overflow-y-auto, space-y-4
- User messages: Right-aligned, max-w-md, rounded-2xl, p-4
- Bot messages: Left-aligned, max-w-lg
- Bot response card: Border, rounded-xl, p-6 with PDF details + download button
- Input area: Fixed bottom, border-top, p-4, flex gap-2

**Message Styling:**
- User bubble: Rounded-2xl, ml-auto
- Bot bubble: Rounded-2xl with sharp corner bottom-left
- Typing indicator: Three animated dots
- PDF result card within bot message: Nested card with border-left accent

### Buttons
**Primary Actions:** Solid fill, px-6 py-2, rounded-lg, font-medium
**Secondary Actions:** Border only, same padding
**Icon Buttons:** Square, p-2, rounded-lg
**Download Buttons:** Full width within cards, py-3, with download icon

### Badges & Tags
**Category Badges:** Rounded-full, px-3 py-1, text-xs, font-medium
**Tag Pills:** Inline-flex, gap-2, rounded-full, px-2.5 py-0.5, text-xs
**Status Indicators:** Dot + text, inline-flex items-center

## Dashboard Layouts

### Admin Dashboard
- Top metrics row: 4-column grid (Total PDFs, Total Users, Downloads Today, Storage Used)
- Metric cards: Rounded-xl, p-6, with large number (text-3xl) and icon
- Recent uploads section: 3-column grid of PDF cards
- Quick actions: Fixed buttons in bottom-right for "Upload PDF" and "Add External Link"

### User Dashboard  
- Hero section: Welcome message with user name, text-3xl font-bold
- Stats row: 2-column grid (Total Downloads, Account Since)
- Recent downloads: List view with cards, space-y-4
- Chatbot CTA: Prominent card with illustration suggestion and action button

## Animations
Use sparingly:
- Card hover: Subtle lift (translate-y-[-2px])
- Button press: Scale down slightly (scale-95)
- Modal entry: Fade + slide from top
- Chatbot typing: Animated ellipsis only

## Images
**Admin Dashboard:** No hero image. Focus on data density and quick actions.
**User Landing/Dashboard:** Small decorative illustration in welcome card (chatbot icon or book stack SVG illustration, ~200px height)
**Chatbot Interface:** Bot avatar icon (32x32) next to bot messages
**Empty States:** Centered SVG illustrations (max 240px) for "no downloads yet" or "no PDFs found"

All icons: Heroicons library (outline style, 20px default size)