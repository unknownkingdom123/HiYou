import { useState, useRef, useEffect } from "react";
import { useLocation } from "wouter";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/lib/auth";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { ThemeToggle } from "@/components/theme-toggle";
import { useToast } from "@/hooks/use-toast";
import { 
  ArrowLeft, 
  Send, 
  Bot, 
  User,
  FileText,
  Download,
  ExternalLink,
  Loader2,
  BookOpen
} from "lucide-react";
import type { ChatResponse, Pdf } from "@shared/schema";

type Message = {
  id: string;
  role: "user" | "bot";
  content: string;
  response?: ChatResponse;
  timestamp: Date;
};

function formatFileSize(bytes: number): string {
  if (bytes === 0) return "0 Bytes";
  const k = 1024;
  const sizes = ["Bytes", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
}

function PdfResultCard({ pdf, onDownload }: { pdf: Pdf; onDownload: () => void }) {
  return (
    <Card className="mt-3 border-l-4 border-l-primary">
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-primary/10 shrink-0">
            <FileText className="w-5 h-5 text-primary" />
          </div>
          <div className="flex-1 min-w-0">
            <h4 className="font-semibold truncate">{pdf.title}</h4>
            <p className="text-sm text-muted-foreground">{pdf.author}</p>
            {pdf.description && (
              <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                {pdf.description}
              </p>
            )}
            <div className="flex items-center gap-2 mt-2 flex-wrap">
              <Badge variant="secondary" className="text-xs">
                {pdf.category}
              </Badge>
              <span className="text-xs text-muted-foreground font-mono">
                {formatFileSize(pdf.fileSize)}
              </span>
              {pdf.tags && pdf.tags.length > 0 && (
                <>
                  {pdf.tags.slice(0, 3).map((tag) => (
                    <Badge key={tag} variant="outline" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                </>
              )}
            </div>
          </div>
        </div>
        <Button 
          className="w-full mt-4" 
          onClick={onDownload}
          data-testid={`button-download-${pdf.id}`}
        >
          <Download className="w-4 h-4 mr-2" />
          Download PDF
        </Button>
      </CardContent>
    </Card>
  );
}

function SimilarPdfsSection({ pdfs, onDownload }: { pdfs: Pdf[]; onDownload: (pdf: Pdf) => void }) {
  if (!pdfs || pdfs.length === 0) return null;
  
  return (
    <div className="mt-4">
      <p className="text-sm font-medium text-muted-foreground mb-2">Similar results:</p>
      <div className="space-y-2">
        {pdfs.map((pdf) => (
          <Card key={pdf.id} className="hover-elevate">
            <CardContent className="p-3">
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <FileText className="w-4 h-4 text-muted-foreground shrink-0" />
                  <div className="min-w-0">
                    <p className="font-medium text-sm truncate">{pdf.title}</p>
                    <p className="text-xs text-muted-foreground">{pdf.author}</p>
                  </div>
                </div>
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => onDownload(pdf)}
                  data-testid={`button-similar-download-${pdf.id}`}
                >
                  <Download className="w-4 h-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}

export default function Chat() {
  const { user, token } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      role: "bot",
      content: "Hello! I'm your PDF Library Assistant. Ask me for any book or document, and I'll help you find it. Try something like \"I need Engineering Physics book\" or \"Give me C programming notes\".",
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const chatMutation = useMutation({
    mutationFn: async (message: string) => {
      const response = await apiRequest("POST", "/api/chat", { message });
      return response as ChatResponse;
    },
    onSuccess: (response, message) => {
      const botMessage: Message = {
        id: Date.now().toString(),
        role: "bot",
        content: response.message,
        response,
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, botMessage]);
    },
    onError: (error: Error) => {
      const errorMessage: Message = {
        id: Date.now().toString(),
        role: "bot",
        content: "Sorry, I encountered an error. Please try again.",
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, errorMessage]);
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSend = () => {
    if (!input.trim() || chatMutation.isPending) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input.trim(),
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    chatMutation.mutate(input.trim());
    setInput("");
    inputRef.current?.focus();
  };

  const handleDownload = async (pdf: Pdf) => {
    try {
      await apiRequest("POST", `/api/pdfs/${pdf.id}/track-download`, {});
      queryClient.invalidateQueries({ queryKey: ["/api/user/downloads"] });
      queryClient.invalidateQueries({ queryKey: ["/api/user/stats"] });
      
      const link = document.createElement("a");
      link.href = `/api/pdfs/${pdf.id}/download`;
      link.download = pdf.originalName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      toast({
        title: "Download started",
        description: `Downloading ${pdf.title}`,
      });
    } catch (error) {
      toast({
        title: "Download failed",
        description: "Could not download the file",
        variant: "destructive",
      });
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  if (!user) {
    setLocation("/login");
    return null;
  }

  return (
    <div className="h-screen flex flex-col bg-background">
      <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="max-w-4xl mx-auto px-4 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => setLocation("/dashboard")}
              data-testid="button-back"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex items-center gap-2">
              <div className="flex items-center justify-center w-9 h-9 rounded-full bg-primary/10">
                <Bot className="w-5 h-5 text-primary" />
              </div>
              <div>
                <h1 className="font-semibold">Library Assistant</h1>
                <p className="text-xs text-muted-foreground">AI-powered search</p>
              </div>
            </div>
          </div>
          <ThemeToggle />
        </div>
      </header>

      <ScrollArea className="flex-1 p-4" ref={scrollRef}>
        <div className="max-w-4xl mx-auto space-y-6 pb-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex gap-3 ${message.role === "user" ? "flex-row-reverse" : ""}`}
              data-testid={`message-${message.id}`}
            >
              <Avatar className="h-8 w-8 shrink-0">
                <AvatarFallback className={message.role === "bot" ? "bg-primary/10 text-primary" : "bg-secondary"}>
                  {message.role === "bot" ? (
                    <Bot className="w-4 h-4" />
                  ) : (
                    <User className="w-4 h-4" />
                  )}
                </AvatarFallback>
              </Avatar>
              <div className={`flex flex-col gap-1 max-w-lg ${message.role === "user" ? "items-end" : ""}`}>
                <div
                  className={`rounded-2xl p-4 ${
                    message.role === "user"
                      ? "bg-primary text-primary-foreground rounded-br-md"
                      : "bg-card border rounded-bl-md"
                  }`}
                >
                  <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                </div>
                
                {message.response?.bestMatch && (
                  <PdfResultCard 
                    pdf={message.response.bestMatch} 
                    onDownload={() => handleDownload(message.response!.bestMatch!)}
                  />
                )}
                
                {message.response?.externalLink && !message.response.bestMatch && (
                  <Card className="mt-3 border-l-4 border-l-chart-2">
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <ExternalLink className="w-5 h-5 text-chart-2 shrink-0 mt-0.5" />
                        <div>
                          <h4 className="font-semibold">{message.response.externalLink.title}</h4>
                          {message.response.externalLink.description && (
                            <p className="text-sm text-muted-foreground mt-1">
                              {message.response.externalLink.description}
                            </p>
                          )}
                          <Button 
                            variant="outline" 
                            size="sm" 
                            className="mt-3"
                            asChild
                          >
                            <a 
                              href={message.response.externalLink.url} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              data-testid={`link-external-${message.response.externalLink.id}`}
                            >
                              <ExternalLink className="w-4 h-4 mr-2" />
                              Open Link
                            </a>
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )}
                
                <SimilarPdfsSection 
                  pdfs={message.response?.similar || []} 
                  onDownload={handleDownload}
                />
              </div>
            </div>
          ))}
          
          {chatMutation.isPending && (
            <div className="flex gap-3">
              <Avatar className="h-8 w-8 shrink-0">
                <AvatarFallback className="bg-primary/10 text-primary">
                  <Bot className="w-4 h-4" />
                </AvatarFallback>
              </Avatar>
              <div className="bg-card border rounded-2xl rounded-bl-md p-4">
                <div className="flex items-center gap-2">
                  <div className="flex gap-1">
                    <span className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
                    <span className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
                    <span className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
                  </div>
                  <span className="text-sm text-muted-foreground">Searching library...</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </ScrollArea>

      <div className="border-t bg-background p-4">
        <div className="max-w-4xl mx-auto flex gap-2">
          <Input
            ref={inputRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Ask for a book, e.g., 'I need Engineering Physics notes'"
            className="flex-1"
            disabled={chatMutation.isPending}
            data-testid="input-chat"
          />
          <Button 
            onClick={handleSend} 
            disabled={!input.trim() || chatMutation.isPending}
            data-testid="button-send"
          >
            {chatMutation.isPending ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Send className="w-4 h-4" />
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}
