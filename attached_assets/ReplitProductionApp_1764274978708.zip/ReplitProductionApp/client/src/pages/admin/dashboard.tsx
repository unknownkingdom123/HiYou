import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { AdminLayout } from "@/components/admin-layout";
import { useLocation } from "wouter";
import { 
  FileText, 
  Users, 
  Download, 
  HardDrive,
  Upload,
  Link2,
  TrendingUp,
  Clock
} from "lucide-react";
import type { Pdf } from "@shared/schema";

type AdminStats = {
  totalPdfs: number;
  totalUsers: number;
  totalDownloads: number;
  storageUsed: number;
};

function formatFileSize(bytes: number): string {
  if (bytes === 0) return "0 Bytes";
  const k = 1024;
  const sizes = ["Bytes", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
}

function formatDate(date: string | Date): string {
  return new Date(date).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function StatCard({ 
  title, 
  value, 
  icon: Icon, 
  loading 
}: { 
  title: string; 
  value: string | number; 
  icon: typeof FileText; 
  loading?: boolean;
}) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-4 pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">
          {title}
        </CardTitle>
        <Icon className="h-5 w-5 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        {loading ? (
          <Skeleton className="h-9 w-24" />
        ) : (
          <div className="text-3xl font-bold">{value}</div>
        )}
      </CardContent>
    </Card>
  );
}

export default function AdminDashboard() {
  const [, setLocation] = useLocation();

  const { data: stats, isLoading: statsLoading } = useQuery<AdminStats>({
    queryKey: ["/api/admin/stats"],
  });

  const { data: recentPdfs, isLoading: pdfsLoading } = useQuery<Pdf[]>({
    queryKey: ["/api/admin/pdfs/recent"],
  });

  return (
    <AdminLayout>
      <div className="space-y-8">
        <div>
          <h1 className="text-4xl font-bold">Dashboard</h1>
          <p className="text-muted-foreground text-lg mt-1">
            Overview of your PDF library
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatCard
            title="Total PDFs"
            value={stats?.totalPdfs ?? 0}
            icon={FileText}
            loading={statsLoading}
          />
          <StatCard
            title="Total Users"
            value={stats?.totalUsers ?? 0}
            icon={Users}
            loading={statsLoading}
          />
          <StatCard
            title="Total Downloads"
            value={stats?.totalDownloads ?? 0}
            icon={Download}
            loading={statsLoading}
          />
          <StatCard
            title="Storage Used"
            value={stats ? formatFileSize(stats.storageUsed) : "0 Bytes"}
            icon={HardDrive}
            loading={statsLoading}
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-2">
            <CardHeader className="flex flex-row items-center justify-between gap-4">
              <div>
                <CardTitle className="text-lg">Recent Uploads</CardTitle>
                <CardDescription>Latest PDFs added to the library</CardDescription>
              </div>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setLocation("/admin/library")}
                data-testid="button-view-library"
              >
                View All
              </Button>
            </CardHeader>
            <CardContent>
              {pdfsLoading ? (
                <div className="space-y-4">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="flex items-center gap-4">
                      <Skeleton className="w-10 h-10 rounded-lg" />
                      <div className="flex-1 space-y-2">
                        <Skeleton className="h-4 w-3/4" />
                        <Skeleton className="h-3 w-1/2" />
                      </div>
                    </div>
                  ))}
                </div>
              ) : recentPdfs && recentPdfs.length > 0 ? (
                <div className="space-y-4">
                  {recentPdfs.slice(0, 5).map((pdf) => (
                    <div 
                      key={pdf.id} 
                      className="flex items-center gap-4"
                      data-testid={`recent-pdf-${pdf.id}`}
                    >
                      <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-primary/10">
                        <FileText className="w-5 h-5 text-primary" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium truncate">{pdf.title}</p>
                        <p className="text-sm text-muted-foreground">{pdf.author}</p>
                      </div>
                      <div className="text-right shrink-0">
                        <Badge variant="secondary" className="text-xs">
                          {pdf.category}
                        </Badge>
                        <p className="text-xs text-muted-foreground mt-1">
                          {formatFileSize(pdf.fileSize)}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <FileText className="w-12 h-12 mx-auto mb-3 opacity-50" />
                  <p>No PDFs uploaded yet</p>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="mt-3"
                    onClick={() => setLocation("/admin/upload")}
                  >
                    Upload First PDF
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Quick Actions</CardTitle>
              <CardDescription>Common admin tasks</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button 
                className="w-full justify-start" 
                onClick={() => setLocation("/admin/upload")}
                data-testid="button-quick-upload"
              >
                <Upload className="w-4 h-4 mr-3" />
                Upload New PDF
              </Button>
              <Button 
                variant="outline" 
                className="w-full justify-start"
                onClick={() => setLocation("/admin/links")}
                data-testid="button-quick-link"
              >
                <Link2 className="w-4 h-4 mr-3" />
                Add External Link
              </Button>
              <Button 
                variant="outline" 
                className="w-full justify-start"
                onClick={() => setLocation("/admin/users")}
                data-testid="button-quick-users"
              >
                <Users className="w-4 h-4 mr-3" />
                Manage Users
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </AdminLayout>
  );
}
