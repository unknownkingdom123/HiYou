import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/lib/auth";
import { useLocation, Link } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { ThemeToggle } from "@/components/theme-toggle";
import { 
  BookOpen, 
  Download, 
  Calendar, 
  MessageSquare, 
  LogOut, 
  FileText,
  Clock,
  ArrowRight
} from "lucide-react";
import type { DownloadHistoryWithPdf } from "@shared/schema";

function formatFileSize(bytes: number): string {
  if (bytes === 0) return "0 Bytes";
  const k = 1024;
  const sizes = ["Bytes", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
}

function formatDate(date: string | Date): string {
  return new Date(date).toLocaleDateString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
}

export default function Dashboard() {
  const { user, logout, token } = useAuth();
  const [, setLocation] = useLocation();

  const { data: stats, isLoading: statsLoading } = useQuery<{ totalDownloads: number; memberSince: string }>({
    queryKey: ["/api/user/stats"],
    enabled: !!token,
  });

  const { data: downloads, isLoading: downloadsLoading } = useQuery<DownloadHistoryWithPdf[]>({
    queryKey: ["/api/user/downloads"],
    enabled: !!token,
  });

  const handleLogout = () => {
    logout();
    setLocation("/login");
  };

  if (!user) {
    setLocation("/login");
    return null;
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-primary/10">
              <BookOpen className="w-5 h-5 text-primary" />
            </div>
            <span className="font-semibold text-lg hidden sm:inline">PDF Library</span>
          </div>
          
          <div className="flex items-center gap-2">
            <Button 
              variant="default" 
              onClick={() => setLocation("/chat")}
              data-testid="button-open-chat"
            >
              <MessageSquare className="w-4 h-4 mr-2" />
              AI Chat
            </Button>
            <ThemeToggle />
            <div className="flex items-center gap-3 pl-2 border-l">
              <Avatar className="h-9 w-9">
                <AvatarFallback className="bg-primary/10 text-primary font-medium">
                  {user.name.charAt(0).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={handleLogout}
                data-testid="button-logout"
              >
                <LogOut className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">
            Welcome back, {user.name.split(" ")[0]}!
          </h1>
          <p className="text-muted-foreground text-lg">
            Access your library and chat with our AI assistant
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-4 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Total Downloads
              </CardTitle>
              <Download className="h-5 w-5 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              {statsLoading ? (
                <Skeleton className="h-9 w-20" />
              ) : (
                <div className="text-3xl font-bold" data-testid="text-total-downloads">
                  {stats?.totalDownloads ?? 0}
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-4 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Member Since
              </CardTitle>
              <Calendar className="h-5 w-5 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              {statsLoading ? (
                <Skeleton className="h-9 w-32" />
              ) : (
                <div className="text-3xl font-bold" data-testid="text-member-since">
                  {stats?.memberSince ? formatDate(stats.memberSince) : "N/A"}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <Card className="mb-8 bg-gradient-to-br from-primary/5 to-primary/10 border-primary/20">
          <CardContent className="p-6">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="flex items-center justify-center w-14 h-14 rounded-2xl bg-primary/10">
                  <MessageSquare className="w-7 h-7 text-primary" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold">AI Library Assistant</h3>
                  <p className="text-muted-foreground">
                    Ask for any book or document - our AI will find it for you
                  </p>
                </div>
              </div>
              <Button onClick={() => setLocation("/chat")} data-testid="button-start-chat">
                Start Chatting
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </CardContent>
        </Card>

        <div>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-semibold">Recent Downloads</h2>
          </div>

          {downloadsLoading ? (
            <div className="space-y-4">
              {[1, 2, 3].map((i) => (
                <Card key={i}>
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <Skeleton className="w-12 h-12 rounded-lg" />
                      <div className="flex-1 space-y-2">
                        <Skeleton className="h-5 w-3/4" />
                        <Skeleton className="h-4 w-1/2" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : downloads && downloads.length > 0 ? (
            <div className="space-y-4">
              {downloads.map((download) => (
                <Card key={download.id} className="hover-elevate" data-testid={`card-download-${download.id}`}>
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className="flex items-center justify-center w-12 h-12 rounded-lg bg-primary/10">
                        <FileText className="w-6 h-6 text-primary" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-semibold truncate">{download.pdf.title}</h3>
                        <p className="text-sm text-muted-foreground">{download.pdf.author}</p>
                        <div className="flex items-center gap-3 mt-2 flex-wrap">
                          <Badge variant="secondary" className="text-xs">
                            {download.pdf.category}
                          </Badge>
                          <span className="text-xs text-muted-foreground font-mono">
                            {formatFileSize(download.pdf.fileSize)}
                          </span>
                          <span className="text-xs text-muted-foreground flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {formatDate(download.downloadedAt)}
                          </span>
                        </div>
                      </div>
                      <Button 
                        variant="outline" 
                        size="sm"
                        asChild
                      >
                        <a 
                          href={`/api/pdfs/${download.pdf.id}/download`}
                          download
                          data-testid={`button-redownload-${download.id}`}
                        >
                          <Download className="w-4 h-4" />
                        </a>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="p-12 text-center">
                <div className="flex items-center justify-center w-16 h-16 rounded-2xl bg-muted mx-auto mb-4">
                  <Download className="w-8 h-8 text-muted-foreground" />
                </div>
                <h3 className="font-semibold text-lg mb-2">No downloads yet</h3>
                <p className="text-muted-foreground mb-4">
                  Start chatting with our AI to find and download PDFs
                </p>
                <Button onClick={() => setLocation("/chat")} data-testid="button-empty-chat">
                  <MessageSquare className="w-4 h-4 mr-2" />
                  Start Chatting
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </main>
    </div>
  );
}
