# AI PDF Library Bot

A full-stack web application that provides an AI-powered document search and download system with separate user and admin interfaces.

## Overview

This application allows users to find and download PDF documents through an intelligent chatbot interface that uses fuzzy matching to understand natural language queries. Administrators can manage the library by uploading PDFs, adding external links, and monitoring user activity.

## Architecture

### Frontend (React + Vite)
- **Framework**: React with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query for server state
- **UI Components**: Shadcn UI components with Tailwind CSS
- **Authentication**: JWT tokens stored in localStorage

### Backend (Express.js)
- **Authentication**: JWT with bcrypt password hashing
- **File Uploads**: Multer for PDF upload handling
- **AI Search**: Fuse.js for fuzzy matching and similarity scoring
- **Storage**: In-memory storage (can be upgraded to PostgreSQL)

## Key Features

### User Features
- User registration and authentication
- AI chatbot for natural language document search
- PDF download with history tracking
- User dashboard with download statistics

### Admin Features
- Separate admin authentication
- PDF upload with metadata (title, author, category, tags)
- Library management (edit, delete PDFs)
- External link management for resources not in the library
- User management with activity monitoring

## Project Structure

```
/client
  /src
    /components      # Reusable UI components
    /pages           # Page components
      /admin         # Admin dashboard pages
    /lib             # Utilities and helpers
    /hooks           # Custom React hooks

/server
  index.ts           # Server entry point
  routes.ts          # API endpoints
  storage.ts         # Data storage interface
  vite.ts            # Vite dev server setup

/shared
  schema.ts          # Shared TypeScript types and Zod schemas

/uploads             # PDF file storage directory
```

## API Endpoints

### Authentication
- `POST /api/auth/signup` - User registration
- `POST /api/auth/login` - User login
- `POST /api/auth/admin/login` - Admin login

### User Endpoints
- `GET /api/user/stats` - Get user statistics
- `GET /api/user/downloads` - Get download history
- `POST /api/chat` - AI chatbot search

### PDF Endpoints
- `GET /api/pdfs/:id/download` - Download PDF
- `POST /api/pdfs/:id/track-download` - Track download

### Admin Endpoints
- `GET /api/admin/stats` - Dashboard statistics
- `GET /api/admin/pdfs` - List all PDFs
- `POST /api/admin/pdfs` - Upload new PDF
- `PATCH /api/admin/pdfs/:id` - Update PDF metadata
- `DELETE /api/admin/pdfs/:id` - Delete PDF
- `GET /api/admin/links` - List external links
- `POST /api/admin/links` - Add external link
- `DELETE /api/admin/links/:id` - Delete external link
- `GET /api/admin/users` - List all users
- `GET /api/admin/users/:id/downloads` - Get user downloads

## Default Admin Credentials

- **Email**: admin@library.com
- **Password**: admin123

## Development

The application runs on port 5000 with Vite handling the frontend development server and Express serving the API.

## Recent Changes

- Initial implementation of full-stack PDF library bot
- Implemented JWT authentication with admin and user roles
- Created AI chatbot with Fuse.js fuzzy search
- Built admin dashboard with PDF and user management
- Added download tracking and user statistics
